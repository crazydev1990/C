#include<stdio.h>
#include<conio.h>

int main()
{
    int i,j,n;

    for(i=1;i<=9;i++)
    {
       for(j=1;j<=5;j++)
       {
          if(j<=i)
          {
              printf("*");
          }
          else
          {
              printf(" ");
          }
       }
       for(j=1;j<=5;j++)
       {
              if(j>=6-i)
              {
                printf("*");
              }
              else
              {
                printf(" ");
              }
       }
       printf("\n");
    }
    return 0;
}




