#include<stdio.h>
#include<conio.h>

int main()
{
    int i,j,n;

    for(i=1;i<=5;i++)
    {
       for(j=1;j<=i+(5-i)+4;j++)
       {
          if(j>=i && j<=10-i)
          {
              printf("*");
          }
          else
          {
              printf(" ");
          }
       }
       printf("\n");
    }
    return 0;
}



